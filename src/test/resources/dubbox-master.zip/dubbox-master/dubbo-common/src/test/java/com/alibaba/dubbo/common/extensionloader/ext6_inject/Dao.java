package com.alibaba.dubbo.common.extensionloader.ext6_inject;


public interface Dao {
    public void update();
}
